
package progpoe5121;

import java.util.Scanner;

public class ProgPOE5121 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter your username: ");
        String username = scanner.nextLine();
        
        System.out.println("Enter your password: ");
        String password = scanner.nextLine();
        if (!Login.checkPasswordComplexity(password)){
                System.out.println("Invalid.");
                return;
        }
                
        System.out.println("Enter your first name: ");
        String firstName = scanner.nextLine();
        
        System.out.println("Enter your last name: ");
        String lastName = scanner.nextLine();
        
        Login register = new Login();
        register.registerUser(username, password, firstName, lastName);
        String Status = register.returnLoginStatus();
        System.out.println(Status);
    }
    
}
